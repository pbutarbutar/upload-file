    ___________________________________________
   |   __  _ ___  _   _   __  __ __  __   __   |
   |  |  \| | __|| | | |/' _/|  V  |/  \ / _]  |
   |  | | ' | _| | 'v' |`._`.| \_/ | /\ | [/\  |
   |  |_|\__|___|!_/ \_!|___/|_| |_|_||_|\__/  |
   |___________________________________________|
 
  ~ tagDiv 2016 ~
  
  
The documentations is here: 

http://forum.tagdiv.com/newsmag-documentation/


Thanks for your support and feel free to contact us any time :) . 
Our support forum is here:
http://forum.tagdiv.com/ 



Special thanks to Chris S. and to all the forum members that bring value to the community.

We would also like to thank all that contributed to our translations.